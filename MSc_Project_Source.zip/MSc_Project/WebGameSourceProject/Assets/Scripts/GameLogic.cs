﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameLogic : MonoBehaviour
{
    public Image redbox;
    public GameObject[] answers;
    public Text gameScore;
    private float fillAmount = 0f;


    // Start is called before the first frame update
    void Start()
    {
     //   InvokeRepeating("redboxAnimation", 0f, 0.01f);
    }

    // Update is called once per frame
    void Update()
    {
        if (redbox.IsActive())
            RedBoxAnimation(0.03f);
    }

    private void RedBoxAnimation(float speed)
    {
        if (fillAmount <= 1f)
        {
            fillAmount += speed;
            redbox.fillAmount = fillAmount;
        } else
        {
            for (int i= 0; i < answers.Length; i++)
            {
                answers[i].SetActive(true);
            }
        }
    }

    public void ClickedOnCorrectAnswer(int scoreToBeAdded)
    {
        redbox.gameObject.SetActive(true);
        GameManager.SCORE += scoreToBeAdded;
        gameScore.text = "Hits: " + GameManager.SCORE.ToString() + " / " + GameManager.totalNumberOfQuestions;

        // diable player from clicking the button
        this.gameObject.GetComponent<Image>().enabled = false;
        this.gameObject.GetComponent<Button>().enabled = false;
    }

}
