﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    // GLOBAL VARIABLES
    public static int SCORE = 0;
    public static int totalNumberOfQuestions = 2;


}
